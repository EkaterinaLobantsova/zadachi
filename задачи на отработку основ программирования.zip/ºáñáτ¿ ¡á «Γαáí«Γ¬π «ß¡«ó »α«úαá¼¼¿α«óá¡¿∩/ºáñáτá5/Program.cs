﻿using System.IO;

namespace задание5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите предложение");
            string sentence = Console.ReadLine();
            string[] subs = sentence.Split(' ');
            int letter = 0;
            int max = 0;
            int a = 0;
            for (int i = 0; i < subs.Length; i++)
            {
               letter = subs[i].Length;
                if (letter > max) {
                    max = letter;
                    a = i;
                }
            }
            Console.WriteLine("Самое длинное слово - " + subs[a]);
        }
    }
}