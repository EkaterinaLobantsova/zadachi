﻿namespace задача1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите первое число");
            double firstNum = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите второе число");
            double secondNum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите третье число");
            double thirdNum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите четвёртое число");
            double fourthNum = Convert.ToInt32(Console.ReadLine());
            double average = (firstNum + secondNum + thirdNum + fourthNum) / 4;
            Console.WriteLine("Среднее значение - " + average);
        }
    }
}