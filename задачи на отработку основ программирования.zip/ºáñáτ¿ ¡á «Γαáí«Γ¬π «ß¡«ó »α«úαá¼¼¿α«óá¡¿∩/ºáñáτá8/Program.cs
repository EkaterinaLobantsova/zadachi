﻿namespace задание8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество ступеней");
            int amount = Convert.ToInt32(Console.ReadLine());
            int i = 0;
            string soutput = "";
            while (i < amount)
            {
                i++;
                soutput += Convert.ToString(i);
                Console.WriteLine(soutput);  
            }
        }
    }
}