﻿namespace задание7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите пять чисел через пробел");
            string strarray = Console.ReadLine();
            string[] subs = strarray.Split(' ');
            int[] ints = Array.ConvertAll(subs, s => int.Parse(s));
            int i = 0;
            int min = int.MaxValue;
            int max = int.MinValue;
            for (i = 0; i < ints.Length; i++)
            {
                if (ints[i] < min)
                {
                    min = ints[i];
                }
                if (ints[i] > max)
                {
                    max = ints[i];
                }
            }
            Console.WriteLine("Максимальное число: " + max + "\r\n" + "Минимальное число: " + min);

            /*ввод чисел
             разделить прочитанную строку на массив
            массив перевести в инт
            цикал перебор значений массива
            в теле цикла искать минимальное значение и максимальное
            вывести их
             */

        }
    }
}