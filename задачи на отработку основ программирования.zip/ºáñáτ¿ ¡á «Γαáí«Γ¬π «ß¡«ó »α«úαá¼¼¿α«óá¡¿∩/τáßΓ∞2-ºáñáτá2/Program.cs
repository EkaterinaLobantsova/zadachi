﻿namespace часть2_задание2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] goods  = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
            int i = 0;
            double sum = 0;
            while (i < goods.Length)
            {
                sum += goods[i];
                i++;
            }
            double average = sum / goods.Length;
            int j = 0;
            i = 0;
            while (i < goods.Length)
            {
                if (goods[i] < average)
                {
                    j++;  
                }
                i++;
            }
            Console.WriteLine(j + " видов товара имеют стоимость меньшую, чем средняя стоимость всех видов товара.");
        }
    }
}