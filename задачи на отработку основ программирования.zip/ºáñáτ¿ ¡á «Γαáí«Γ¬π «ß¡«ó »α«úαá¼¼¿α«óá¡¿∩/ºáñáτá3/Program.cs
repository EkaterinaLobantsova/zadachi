﻿using System.ComponentModel.Design;

namespace задача3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выберите шкалу вводимой температуры:\r\n1. Цельсий\r\n2. Кельвин\r\n3. Фаренгейт");
            int enter = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите показатель температуры (градусы):");
            double degree = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Выберите тип шкалы для конвертации:\r\n1. Цельсий\r\n2. Кельвин\r\n3. Фаренгейт");
            int convert = Convert.ToInt32(Console.ReadLine());
            double result;
            if (enter == 1)
            {
                if (convert == 1)
                {
                    result = degree;
                    Console.WriteLine("Вы выбрали: Цельсий->Цельсий. Результат конвертации: " + result);
                }
                else
                {
                    if (convert == 2)
                    {
                        result = degree + 273.15;
                        Console.WriteLine("Вы выбрали: Цельсий->Кельвин. Результат конвертации: " + result);
                    }
                    else
                    {
                        if (convert == 3)
                        {
                            result = degree * 9 / 5 + 32;
                            Console.WriteLine("Вы выбрали: Цельсий->Фаренгейт. Результат конвертации: " + result);
                        }
                    }
                }
            }
            if (enter == 2)
            {
                if (convert == 1)
                {
                    result = degree - 273.15;
                    Console.WriteLine("Вы выбрали: Кельвин->Цельсий. Результат конвертации: " + result);
                }
                else
                {
                    if (convert == 2)
                    {
                        result = degree;
                        Console.WriteLine("Вы выбрали: Кельвин->Кельвин. Результат конвертации: " + result);
                    }

                    else
                    {
                        if (convert == 3)
                        {
                            result = degree * 9 / 5 - 459.67;
                            Console.WriteLine("Вы выбрали: Кельвин->Фаренгейт. Результат конвертации: " + result);
                        }
                    }
                }

            }
            if (enter == 3)
            {
                if (convert == 1)
                {
                    result = (degree - 32) * 5 / 9;
                    Console.WriteLine("Вы выбрали: Фаренгейт->Цельсий. Результат конвертации: " + result);
                }
                else
                {
                    if (convert == 2)
                    {
                        result = (degree + 459.67) * 5 / 9;
                        Console.WriteLine("Вы выбрали: Фаренгейт->Кельвин. Результат конвертации: " + result);
                    }

                    else
                    {
                        if (convert == 3)
                        {
                            result = degree;
                            Console.WriteLine("Вы выбрали: Фаренгейт->Фаренгейт. Результат конвертации: " + result);
                        }
                    }
                }

            }
        }
    }
}