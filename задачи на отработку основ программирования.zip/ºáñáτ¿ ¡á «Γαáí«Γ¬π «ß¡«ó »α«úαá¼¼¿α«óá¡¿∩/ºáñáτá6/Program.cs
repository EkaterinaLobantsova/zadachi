﻿using Microsoft.VisualBasic;

namespace задание6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значения для первого массива через пробел");
            string strarray1 = Console.ReadLine();
            Console.WriteLine("Введите значения для второго массива через пробел");
            string strarray2 = Console.ReadLine();
            string[] subs1 = strarray1.Split(' ');
            string[] subs2 = strarray2.Split(' ');
            int[] ints1 = Array.ConvertAll(subs1, s => int.Parse(s));
            int[] ints2 = Array.ConvertAll(subs2, s => int.Parse(s));
            if (ints1.Length != ints2.Length)
            {
                Console.WriteLine("Введите одинаковое количество цифр");
            }
            else
            {
                int i = 0;
                string sresult = "";
                int mult = 0;
                for (i = 0; i < ints1.Length; i++)
                {
                    mult = ints1[i] * ints2[i];
                    sresult += Convert.ToString(mult,10) + " ";
                }

                Console.WriteLine("Результат: " + sresult);
            }
        }
    }
}