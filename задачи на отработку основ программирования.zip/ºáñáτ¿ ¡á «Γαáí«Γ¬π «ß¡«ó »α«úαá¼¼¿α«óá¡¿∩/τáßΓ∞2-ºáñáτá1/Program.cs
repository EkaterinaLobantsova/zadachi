﻿using System;
using System.ComponentModel.Design;

namespace часть2_задание1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int j = 0;
            string s_i = "";
            string s_j = "";
            string s_res = "";
            string s_multOperation = "";
            string s_row = "";
            string s_space = "";

            for (i = 1; i < 10; i++)
            {
                s_row = "";
                for (j = 1; j < 10; j++)
                {
                    s_i = Convert.ToString(i, 10);
                    s_j = Convert.ToString(j, 10);
                    s_res = Convert.ToString(i * j, 10);
                    if (i * j > 9)
                    {
                        s_space = "   ";
                    }
                    else 
                    {
                        s_space = "    ";
                    }; 
                    
                    s_multOperation = s_i + " x " + s_j + " = " + s_res + s_space;
                    s_row += s_multOperation;

                }
                Console.WriteLine(s_row);
            }
        }
    }
    }
