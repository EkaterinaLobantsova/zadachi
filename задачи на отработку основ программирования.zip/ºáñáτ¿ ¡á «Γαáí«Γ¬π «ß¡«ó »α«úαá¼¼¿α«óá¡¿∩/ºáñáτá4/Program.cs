﻿using System.Xml.Linq;

namespace задание4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите путь к файлу");
            string path = Console.ReadLine();
            string[] subs = path.Split('/');
            int amount = subs.Length - 1;
            Console.WriteLine("Имя файла: " + subs[amount]);
        }
    }
}