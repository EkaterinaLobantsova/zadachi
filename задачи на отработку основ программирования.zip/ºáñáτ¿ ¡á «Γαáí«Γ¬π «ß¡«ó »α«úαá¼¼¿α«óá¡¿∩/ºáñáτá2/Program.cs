﻿using System.Xml.Linq;
using System.Xml.Serialization;

namespace задача2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введи первое число");
            double firstNum = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введи второе число");
            double secondNum = Convert.ToDouble(Console.ReadLine());
            //начало цикла
            int choice;
            do
            {
                Console.WriteLine("Вы ввели числа: " + firstNum + " и " + secondNum + ". Какое действие выполнить ?\r\n1. Сложение\r\n2. Вычитание\r\n3. Умножение\r\n4. Деление\r\n5. Нахождение остатка");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        double plus = firstNum + secondNum;
                        Console.WriteLine("Результат: " + firstNum + " + " + secondNum + " = " + plus);
                        break;
                    case 2:
                        double minus = firstNum - secondNum;
                        Console.WriteLine("Результат: " + firstNum + " - " + secondNum + " = " + minus);
                        break;
                    case 3:
                        double multiply = firstNum * secondNum;
                        Console.WriteLine("Результат: " + firstNum + " * " + secondNum + " = " + multiply);
                        break;
                    case 4:
                        double divide = firstNum / secondNum;
                        if (secondNum == 0)
                        {
                            Console.WriteLine("На ноль делить нельзя!");
                        }
                        else
                        {
                            Console.WriteLine("Результат: " + firstNum + " / " + secondNum + " = " + divide);
                        }
                        break;
                    case 5:
                        double remains = firstNum % secondNum;
                        Console.WriteLine("Результат: остаток от деления " + firstNum + " на " + secondNum + " = " + remains);
                        break;

                    default:
                        Console.WriteLine("Введи цифру от 1 до 5!"); //\r\nКакое действие выполнить ?\r\n1. Сложение\r\n2. Вычитание\r\n3. Умножение\r\n4. Деление\r\n5. Нахождение остатка");

                        break;
                }
            }
            while (choice > 5); 
        }
    }
}